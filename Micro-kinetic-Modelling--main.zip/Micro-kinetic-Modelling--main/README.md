# Micro-kinetic-Modelling-
To conduct micro-kinetic modeling and sensitivity analysis for methane pyrolysis using sodium (Na) as a catalyst in the gas phase, based on the given step reactions.
